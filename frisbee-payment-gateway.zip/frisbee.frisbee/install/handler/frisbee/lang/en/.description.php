<?
$MESS['FRISBEE_MERCHANT'] = 'Frisbee Merchant ID';
$MESS['FRISBEE_MERCHANT_DESC'] = 'Frisbee Merchant ID';
$MESS['FRISBEE_KEY'] = 'Frisbee Key';
$MESS['FRISBEE_KEY_DESC'] = 'Frisbee Key String';
$MESS['FRISBEE_RESPONSE_URL'] = 'Response URL';
$MESS['FRISBEE_RESPONSE_URL_DESC'] = 'Response URL after payment';
$MESS['FRISBEE_CURRENCY'] = 'Currency';
?>
