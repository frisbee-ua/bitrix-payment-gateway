<?
$MESS['FRISBEE_MERCHANT'] = 'Frisbee Merchant ID';
$MESS['FRISBEE_MERCHANT_DESC'] = 'Frisbee Merchant ID';
$MESS['FRISBEE_KEY'] = 'Frisbee Key';
$MESS['FRISBEE_KEY_DESC'] = 'Frisbee Key String';
$MESS['FRISBEE_RESPONSE_URL'] = 'Response URL';
$MESS['FRISBEE_RESPONSE_URL_DESC'] = 'Response URL after payment';
$MESS['FRISBEE_CURRENCY'] = 'Currency';
$MESS['FRISBEE_STATUS_PROCESSING'] = 'Order status while in progress';
$MESS['FRISBEE_STATUS_PROCESSING_DESC'] = 'Order status while in progress';
$MESS['FRISBEE_STATUS_APPROVED'] = 'Order status after payment';
$MESS['FRISBEE_STATUS_APPROVED_DESC'] = 'Order status after payment';
$MESS['FRISBEE_STATUS_CANCELED'] = 'Order status if cancelled';
$MESS['FRISBEE_STATUS_CANCELED_DESC'] = 'Order status if cancelled';
?>
