<?
$MESS['FRISBEE_MERCHANT'] = 'ID мерчанта';
$MESS['FRISBEE_MERCHANT_DESC'] = 'Идентификатор мерчанта Frisbee';
$MESS['FRISBEE_KEY'] = 'Cекретный ключ';
$MESS['FRISBEE_KEY_DESC'] = 'Cекретный ключ вашего мерчанта Frisbee';
$MESS['FRISBEE_RESPONSE_URL'] = 'URL ответа';
$MESS['FRISBEE_RESPONSE_URL_DESC'] = 'URL ответа после оплаты';
$MESS['FRISBEE_CURRENCY'] = 'Валюта';
$MESS['FRISBEE_STATUS_PROCESSING'] = 'Статус заказа в процессе';
$MESS['FRISBEE_STATUS_PROCESSING_DESC'] = 'Статус заказа в процессе';
$MESS['FRISBEE_STATUS_APPROVED'] = 'Статус заказа после оплаты';
$MESS['FRISBEE_STATUS_APPROVED_DESC'] = 'Статус заказа после оплаты';
$MESS['FRISBEE_STATUS_CANCELED'] = 'Статус отмененного заказа';
$MESS['FRISBEE_STATUS_CANCELED_DESC'] = 'Статус отмененного заказа';
?>
