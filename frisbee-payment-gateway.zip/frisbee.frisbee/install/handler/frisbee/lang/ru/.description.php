<?
$MESS['FRISBEE_MERCHANT'] = 'ID мерчанта';
$MESS['FRISBEE_MERCHANT_DESC'] = 'Идентификатор мерчанта Frisbee';
$MESS['FRISBEE_KEY'] = 'Cекретный ключ';
$MESS['FRISBEE_KEY_DESC'] = 'Cекретный ключ вашего мерчанта Frisbee';
$MESS['FRISBEE_RESPONSE_URL'] = 'URL ответа';
$MESS['FRISBEE_RESPONSE_URL_DESC'] = 'URL ответа после оплаты';
$MESS['FRISBEE_CURRENCY'] = 'Валюта';
?>
