<?
$MESS['FRISBEE_MERCHANT'] = 'ID мерчанта';
$MESS['FRISBEE_MERCHANT_DESC'] = 'Ідентифікатор мерчанта Frisbee';
$MESS['FRISBEE_KEY'] = 'Секретний ключ';
$MESS['FRISBEE_KEY_DESC'] = 'Цекретний ключ вашого мерчанта Frisbee';
$MESS['FRISBEE_RESPONSE_URL'] = 'URL адреса після оплати';
$MESS['FRISBEE_RESPONSE_URL_DESC'] = 'URL адреса після оплати';
$MESS['FRISBEE_CURRENCY'] = 'Валюта';
$MESS['FRISBEE_STATUS_PROCESSING'] = 'Статус замовлення що виконується';
$MESS['FRISBEE_STATUS_PROCESSING_DESC'] = 'Статус замовлення що виконується';
$MESS['FRISBEE_STATUS_APPROVED'] = 'Статус замовлення після успішної оплати';
$MESS['FRISBEE_STATUS_APPROVED_DESC'] = 'Статус замовлення після успішної оплати';
$MESS['FRISBEE_STATUS_CANCELED'] = 'Статус скасованого замовлення';
$MESS['FRISBEE_STATUS_CANCELED_DESC'] = 'Статус скасованого замовлення';
?>
