<?
$MESS['FRISBEE_MERCHANT'] = 'ID мерчанта';
$MESS['FRISBEE_MERCHANT_DESC'] = 'Ідентифікатор мерчанта Frisbee';
$MESS['FRISBEE_KEY'] = 'Секретний ключ';
$MESS['FRISBEE_KEY_DESC'] = 'Цекретний ключ вашого мерчанта Frisbee';
$MESS['FRISBEE_RESPONSE_URL'] = 'URL адреса після оплати';
$MESS['FRISBEE_RESPONSE_URL_DESC'] = 'URL адреса після оплати';
$MESS['FRISBEE_CURRENCY'] = 'Валюта';
?>
