<?
global $MESS;

$MESS['FRISBEE_MERCHANT'] = 'Frisbee Merchant';
$MESS['FRISBEE_PAYMENT_BUTTON'] = 'Pay';
$MESS['FRISBEE_PAYMENT_PAID'] = 'Order Already Paid';
$MESS['FRISBEE_ERROR'] = 'Error during payment';
$MESS['FRISBEE_STATUS_PROCESSING'] = 'Order status while in progress';
$MESS['FRISBEE_STATUS_PROCESSING_DESC'] = 'Order status while in progress';
$MESS['FRISBEE_STATUS_APPROVED'] = 'Order status after payment';
$MESS['FRISBEE_STATUS_APPROVED_DESC'] = 'Order status after payment';
$MESS['FRISBEE_STATUS_CANCELED'] = 'Order status if cancelled';
$MESS['FRISBEE_STATUS_CANCELED_DESC'] = 'Order status if cancelled';
?>
