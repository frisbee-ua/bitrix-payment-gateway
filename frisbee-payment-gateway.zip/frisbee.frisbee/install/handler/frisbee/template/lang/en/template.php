<?
global $MESS;

$MESS['FRISBEE_MERCHANT'] = 'Frisbee Merchant';
$MESS['FRISBEE_PAYMENT_BUTTON'] = 'Pay';
$MESS['FRISBEE_PAYMENT_PAID'] = 'Order Already Paid';
$MESS['FRISBEE_ERROR'] = 'Error during payment';
?>
