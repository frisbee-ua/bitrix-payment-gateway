<?
global $MESS;

$MESS['FRISBEE_MERCHANT'] = 'Frisbee мерчант';
$MESS['PAYMENT_BUTTON'] = 'Оплатить';
$MESS['FRISBEE_PAYMENT_PAID'] = 'Заказ уже оплачен';
$MESS['FRISBEE_ERROR'] = 'Ошибка при оплате';
$MESS['FRISBEE_STATUS_PROCESSING'] = 'Статус заказа в процессе';
$MESS['FRISBEE_STATUS_PROCESSING_DESC'] = 'Статус заказа в процессе';
$MESS['FRISBEE_STATUS_APPROVED'] = 'Статус заказа после оплаты';
$MESS['FRISBEE_STATUS_APPROVED_DESC'] = 'Статус заказа после оплаты';
$MESS['FRISBEE_STATUS_CANCELED'] = 'Статус отмененного заказа';
$MESS['FRISBEE_STATUS_CANCELED_DESC'] = 'Статус отмененного заказа';
?>
