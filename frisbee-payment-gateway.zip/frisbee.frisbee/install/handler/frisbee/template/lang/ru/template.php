<?
global $MESS;

$MESS['FRISBEE_MERCHANT'] = 'Frisbee мерчант';
$MESS['PAYMENT_BUTTON'] = 'Оплатить';
$MESS['FRISBEE_PAYMENT_PAID'] = 'Заказ уже оплачен';
$MESS['FRISBEE_ERROR'] = 'Ошибка при оплате';
?>
