<?
global $MESS;

$MESS['FRISBEE_MERCHANT'] = 'Frisbee мерчант';
$MESS['PAYMENT_BUTTON'] = 'Оплатити';
$MESS['FRISBEE_PAYMENT_PAID'] = 'Замовлення вже оплачене';
$MESS['FRISBEE_ERROR'] = 'Помилка під час оплати';
?>
