<?
$arModuleVersion = array(
	'VERSION' => '1.0.0',
	'VERSION_DATE' => '2021-09-02 18:41:59'
);
?>
